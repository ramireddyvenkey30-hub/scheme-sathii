# SchemeSathi – Frontend Plan (YojanaVoice Hack)

## 1. Goal
A mobile-first, voice-enabled web app (Hindi + English) that takes a citizen's profile by **speaking or tapping icon cards**, matches them to welfare schemes, reads the benefits aloud, and gives a document checklist. **Frontend only** – no server; all data and rules run in the browser.

## 2. Scope
| Must-have feature | How it is built | File |
|---|---|---|
| Regional voice query + transcription | Web Speech `SpeechRecognition`, `hi-IN` / `en-IN`, live transcript line | app.js `listen()` |
| 5-question guided questionnaire | Category, Income, Occupation, Gender, State as large icon cards, progress bar, question read aloud | app.js `question()` |
| Scheme matching engine | Declarative rule objects (`occupation`, `category`, `gender`, `state`, `maxIncome`) evaluated by one filter | data.js `SCHEMES`, app.js `matches()` |
| Spoken scheme explainer | `SpeechSynthesisUtterance`: name, benefit, documents, steps; Listen button per scheme | app.js `speak()` |
| Document checklist builder | Union of docs of matched schemes, tick-boxes saved in localStorage, print + download | app.js `checklist()` |
| Hindi/English toggle + dark theme | One `UI` string table, header toggle, high-contrast dark palette, 20px base type, 48px+ touch targets | data.js `UI`, style.css |

Stretch included because it is cheap: WhatsApp share, CSC finder (Google Maps link). Skipped: form-filling simulator.

## 3. Architecture (4 files, no build step, no dependencies)
- `index.html` – semantic shell: header (voice + language toggles), notice bar, `<main>`.
- `style.css` – dark theme, grid cards, print stylesheet (prints only the checklist).
- `data.js` – UI strings, option cards, voice keywords, documents, 15 schemes.
- `app.js` – state, voice in/out, parser, matcher, three views (home / question / results), click delegation.

## 4. Data model
- Answers: `{category, income, occupation, gender, state}` saved to localStorage.
- Scheme: `{id, en, hi, ben:{en,hi}, docs:[keys], how:{en,hi}, rule:{…}}`. Missing rule field = open to all.
- Income buckets: <1L, 1–2.5L, 2.5–5L, >5L; a scheme matches if the bucket's lower bound is under its `maxIncome`.

## 5. User flow
1. Home: big mic + "Start questions".
2. **Voice path**: speak a sentence -> parser fills recognised fields -> results appear at once, with confirmation chips (tap to change) and a "answer remaining questions" button.
3. **Card path**: 5 steps, each question spoken aloud; tapping a card moves on.
4. Results: scheme cards with Listen button -> combined document checklist -> print / download / WhatsApp / CSC.

## 6. Voice parsing
Lower-case transcript, then keyword lists (Devanagari, romanised Hindi, English) set occupation, gender, category and state; a regex reads "N lakh / hazaar" into an income bucket.
Demo sentence "Main chhota kisan hoon, meri aay 1 lakh se kam hai" -> Farmer + Below ₹1 lakh -> PM-Kisan, PM Fasal Bima and more.

## 7. Risks and handling
| Risk | Handling |
|---|---|
| Transcription errors | Recognised answers shown as icon chips; tap to correct |
| No Hindi voice on phone | Notice bar + full text on every card |
| Browser lacks SpeechRecognition | Notice bar; cards still work (Chrome Android recommended) |
| Mic needs secure origin | Serve on `localhost` or HTTPS |
| Scheme data accuracy | Sample data; verify against official portals before real use |

## 8. Build and test steps
1. Data + rules (done) -> 2. Matcher (smoke-tested in Node) -> 3. Views and voice -> 4. Styling and print.
Manual checks on a phone: mic permission, Hindi dictation, Hindi voice playback, language toggle mid-flow, checklist persistence, print preview.

## 9. Run
`cd schemesathi && python3 -m http.server 8000`, then open `http://localhost:8000` in Chrome. For a phone, deploy to any HTTPS static host (GitHub Pages, Netlify).
