const $=s=>document.querySelector(s);
const ST=JSON.parse(localStorage.getItem('ss')||'{}');
const S={lang:ST.lang||'hi',voice:ST.voice!==false,ans:ST.ans||{},chk:ST.chk||{},view:'home',step:0,listening:false,heard:''};
const save=()=>localStorage.setItem('ss',JSON.stringify({lang:S.lang,voice:S.voice,ans:S.ans,chk:S.chk}));
const KEYS=['category','income','occupation','gender','state'];
const t=k=>UI[k][S.lang], L=o=>o[S.lang];
const opt=(k,id)=>OPT[k].find(o=>o.id===id);
const next=()=>KEYS.findIndex(k=>!S.ans[k]);
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
const TTS='speechSynthesis' in window;
const bcp=()=>S.lang==='hi'?'hi-IN':'en-IN';

// ---- Speech output ----
function speak(text){
  if(!TTS)return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.lang=bcp();
  const v=speechSynthesis.getVoices().find(v=>v.lang.replace('_','-').toLowerCase().startsWith(S.lang));
  if(v)u.voice=v;
  speechSynthesis.speak(u);
}

// ---- Speech input: transcript -> answers ----
const NUM={ek:1,do:2,teen:3,char:4,paanch:5,panch:5,'एक':1,'दो':2,'तीन':3,'चार':4,'पांच':5,'पाँच':5};
function parse(raw){
  const x=' '+raw.toLowerCase().replace(/[.,!?]/g,' ')+' ',p={};
  for(const f in KW)for(const id in KW[f])if(KW[f][id].some(w=>x.includes(w))){p[f]=id;break}
  const st=OPT.state.find(s=>s.id!=='other'&&(x.includes(s.en.toLowerCase())||x.includes(s.hi)));
  if(st)p.state=st.id;
  const m=x.match(/(\d+(?:\.\d+)?|ek|do|teen|char|paanch|panch|एक|दो|तीन|चार|पांच|पाँच)\s*(lakhs?|lac|लाख|hazaar|hazar|thousand|हज़ार|हजार)/);
  if(m){
    const v=(NUM[m[1]]||parseFloat(m[1]))*(/lakh|lac|लाख/.test(m[2])?1e5:1e3);
    p.income=v<=1e5?'i1':v<=25e4?'i2':v<=5e5?'i3':'i4';
  }
  return p;
}
function listen(){
  if(!SR)return;
  if(S.listening){S.rec.stop();return}
  const r=S.rec=new SR();
  r.lang=bcp();r.interimResults=true;S.heard='';S.listening=true;
  if(TTS)speechSynthesis.cancel();
  r.onresult=e=>{
    const txt=[...e.results].map(x=>x[0].transcript).join(' ');
    S.heard=txt;
    const h=$('#heard');if(h)h.textContent=txt;
    if(e.results[e.results.length-1].isFinal)apply(parse(txt));
  };
  r.onerror=()=>{S.heard=t('micErr')};
  r.onend=()=>{S.listening=false;render()};
  r.start();render();
}
function apply(p){
  if(!Object.keys(p).length){S.heard+=' — '+t('nomatch');render();return}
  Object.assign(S.ans,p);save();
  const n=next();
  if(S.view==='q'&&n>=0)S.step=n;else S.view='results';
  render(1);
  if(S.view==='results'&&S.voice)speak(`${matches().length} ${t('found')}`);
}

// ---- Matching engine (declarative rules; unanswered = wildcard, except gender/state-restricted schemes) ----
function matches(){
  const a=S.ans,inc=a.income?opt('income',a.income).min:null;
  return SCHEMES.filter(({rule:r})=>
    (!r.occupation||!a.occupation||r.occupation.includes(a.occupation))&&
    (!r.category||!a.category||r.category.includes(a.category))&&
    (!r.gender||r.gender.includes(a.gender))&&
    (!r.state||r.state.includes(a.state))&&
    (!r.maxIncome||inc===null||inc<r.maxIncome));
}
const docList=()=>[...new Set(matches().flatMap(s=>s.docs))];
const summary=()=>`*${t('logo')}*\n\n`+matches().map(s=>`• ${L(s)}: ${L(s.ben)}`).join('\n')+`\n\n${t('docs')}:\n`+docList().map(d=>'☐ '+L(DOCS[d])).join('\n');
const schemeSpeech=s=>`${L(s)}. ${t('benefit')}: ${L(s.ben)}. ${t('docs')}: ${s.docs.map(d=>L(DOCS[d])).join(', ')}. ${t('steps')}: ${L(s.how)}`;

// ---- Views ----
const mic=()=>SR?`<div class="mic-wrap"><button class="mic ${S.listening?'on':''}" data-act="mic" aria-label="${t('tapMic')}">🎤</button><p>${S.listening?t('listening'):t('tapMic')}</p><p id="heard" class="heard">${S.heard}</p></div>`:'';
const chips=()=>KEYS.filter(k=>S.ans[k]).map(k=>{const o=opt(k,S.ans[k]);return `<button class="chip" data-act="edit" data-k="${k}">${o.i} ${L(o)}</button>`}).join('');

const home=()=>`<section class="hero"><p class="lead">${t('tagline')}</p>${mic()}<p class="hint">${t('example')}</p>
<button class="btn" data-act="start">${t('start')}</button>
${KEYS.some(k=>S.ans[k])?`<button class="btn ghost" data-act="results">${t('results')}</button>`:''}</section>`;

function question(){
  const k=KEYS[S.step];
  return `<section><div class="dots">${KEYS.map((_,i)=>`<i class="${i<=S.step?'on':''}"></i>`).join('')}</div>
<h2>${t('q_'+k)} <button class="icon" data-act="say" aria-label="${t('listen')}">🔊</button></h2>
<div class="grid ${k==='state'?'small':''}">${OPT[k].map(o=>`<button class="card ${S.ans[k]===o.id?'sel':''}" data-act="pick" data-v="${o.id}"><span>${o.i}</span>${L(o)}</button>`).join('')}</div>
${mic()}${S.step>0?`<button class="btn ghost" data-act="back">${t('back')}</button>`:''}</section>`;
}

const card=s=>`<article class="scheme"><h3>${L(s)}</h3><p class="ben">${L(s.ben)}</p>
<p><b>${t('docs')}:</b> ${s.docs.map(d=>L(DOCS[d])).join(', ')}</p><p><b>${t('steps')}:</b> ${L(s.how)}</p>
<button class="btn small no-print" data-act="listen" data-id="${s.id}">🔊 ${t('listen')}</button></article>`;

const checklist=()=>`<section id="checklist"><h2>${t('checklist')}</h2>
${docList().map(d=>`<label class="check"><input type="checkbox" data-act="chk" data-d="${d}" ${S.chk[d]?'checked':''}> ${L(DOCS[d])}</label>`).join('')}
<div class="row no-print"><button class="btn small" data-act="print">🖨️ ${t('print')}</button><button class="btn small" data-act="dl">⬇️ ${t('download')}</button><button class="btn small" data-act="wa">💬 ${t('whatsapp')}</button>
<a class="btn small" target="_blank" rel="noopener" href="https://www.google.com/maps/search/Common+Service+Centre+near+me">📍 ${t('csc')}</a></div></section>`;

function results(){
  const m=matches();
  return `<section><h2>${t('results')} (${m.length})</h2><p class="lead">${t('confirm')}</p><div class="chips">${chips()}</div>
${next()>=0?`<button class="btn ghost" data-act="refine">${t('refine')}</button>`:''}${mic()}
${m.length?m.map(card).join('')+checklist():`<p>${t('none')}</p>`}
<button class="btn ghost no-print" data-act="reset">${t('reset')}</button></section>`;
}

function notice(){
  const n=!SR?t('noSR'):(TTS&&S.lang==='hi'&&!speechSynthesis.getVoices().some(v=>/^hi/i.test(v.lang)))?t('noHi'):'';
  $('#notice').textContent=n;$('#notice').hidden=!n;
}
function render(nav){
  $('#app').innerHTML={home,q:question,results}[S.view]();
  document.documentElement.lang=S.lang;
  $('#logo').textContent=t('logo');
  $('#vt').textContent=S.voice?'🔊':'🔇';
  $('#lt').textContent=S.lang==='hi'?'English':'हिंदी';
  notice();
  if(nav){
    window.scrollTo(0,0);
    if(S.voice&&S.view==='q')speak(t('q_'+KEYS[S.step]));
  }
}

// ---- Actions ----
const A={
  start(){S.view='q';S.step=Math.max(next(),0);render(1)},
  results(){S.view='results';render(1)},
  refine(){S.view='q';S.step=next();render(1)},
  edit(b){S.view='q';S.step=KEYS.indexOf(b.dataset.k);render(1)},
  pick(b){
    S.ans[KEYS[S.step]]=b.dataset.v;save();
    const n=next();
    if(n<0)S.view='results';else S.step=n;
    render(1);
  },
  back(){S.step--;render(1)},
  say(){speak(t('q_'+KEYS[S.step]))},
  mic:listen,
  listen(b){speak(schemeSpeech(SCHEMES.find(s=>s.id===b.dataset.id)))},
  chk(b){S.chk[b.dataset.d]=b.checked;save()},
  print(){window.print()},
  dl(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([summary()],{type:'text/plain'}));a.download='schemesathi.txt';a.click()},
  wa(){window.open('https://wa.me/?text='+encodeURIComponent(summary()),'_blank')},
  reset(){S.ans={};S.chk={};S.heard='';save();S.view='home';render(1)},
  voice(){S.voice=!S.voice;if(!S.voice&&TTS)speechSynthesis.cancel();save();render()},
  lang(){S.lang=S.lang==='hi'?'en':'hi';if(TTS)speechSynthesis.cancel();S.heard='';save();render()}
};
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(b&&A[b.dataset.act])A[b.dataset.act](b)});
if(TTS)speechSynthesis.onvoiceschanged=notice;
render();
