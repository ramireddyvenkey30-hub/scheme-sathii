// ---- UI strings (English / Hindi) ----
const UI={
 logo:{en:'SchemeSathi',hi:'स्कीमसाथी'},
 tagline:{en:'Find government schemes you qualify for. Just speak.',hi:'अपने लिए सरकारी योजनाएं खोजें। बस बोलिए।'},
 tapMic:{en:'Tap and speak',hi:'दबाकर बोलिए'},
 listening:{en:'Listening… tap to stop',hi:'सुन रहा हूं… रोकने के लिए दबाएं'},
 example:{en:'Say: "I am a small farmer, my income is under 1 lakh"',hi:'बोलिए: "मैं छोटा किसान हूं, मेरी आय 1 लाख से कम है"'},
 start:{en:'Start questions',hi:'सवाल शुरू करें'},
 back:{en:'Back',hi:'पीछे'},
 reset:{en:'Start over',hi:'फिर से शुरू करें'},
 q_category:{en:'Which category are you from?',hi:'आप किस श्रेणी से हैं?'},
 q_income:{en:'What is your yearly family income?',hi:'आपके परिवार की सालाना आय कितनी है?'},
 q_occupation:{en:'What work do you do?',hi:'आप क्या काम करते हैं?'},
 q_gender:{en:'Are you a woman or a man?',hi:'आप महिला हैं या पुरुष?'},
 q_state:{en:'Which state do you live in?',hi:'आप किस राज्य में रहते हैं?'},
 confirm:{en:'Your answers (tap to change)',hi:'आपके उत्तर (बदलने के लिए दबाएं)'},
 refine:{en:'Answer remaining questions for better results',hi:'बेहतर नतीजों के लिए बाकी सवालों के जवाब दें'},
 results:{en:'Schemes for you',hi:'आपके लिए योजनाएं'},
 found:{en:'schemes found for you',hi:'योजनाएं आपके लिए मिलीं'},
 none:{en:'No scheme found. Try changing your answers.',hi:'कोई योजना नहीं मिली। उत्तर बदलकर देखें।'},
 benefit:{en:'Benefit',hi:'लाभ'},
 docs:{en:'Documents needed',hi:'ज़रूरी दस्तावेज़'},
 steps:{en:'How to apply',hi:'आवेदन कैसे करें'},
 listen:{en:'Listen',hi:'सुनें'},
 checklist:{en:'My document checklist',hi:'मेरे दस्तावेज़ों की सूची'},
 print:{en:'Print',hi:'प्रिंट'},
 download:{en:'Download',hi:'डाउनलोड'},
 whatsapp:{en:'Share on WhatsApp',hi:'व्हाट्सऐप पर भेजें'},
 csc:{en:'Find nearest CSC',hi:'नज़दीकी CSC खोजें'},
 nomatch:{en:'Could not understand. Speak again or tap a card.',hi:'समझ नहीं आया। फिर बोलिए या कार्ड दबाइए।'},
 micErr:{en:'Microphone not available. Allow microphone access or tap a card.',hi:'माइक चालू नहीं है। माइक की अनुमति दें या कार्ड दबाइए।'},
 noSR:{en:'Voice input is not supported in this browser. Please tap the cards (Chrome recommended).',hi:'इस ब्राउज़र में बोलकर जवाब देना उपलब्ध नहीं है। कृपया कार्ड दबाइए (Chrome बेहतर है)।'},
 noHi:{en:'',hi:'इस फ़ोन में हिंदी आवाज़ नहीं है। कृपया कार्ड पर लिखा पढ़ें।'}
};

// ---- Answer options (cards) ----
const OPT={
 category:[
  {id:'general',i:'👤',en:'General',hi:'सामान्य'},
  {id:'obc',i:'👥',en:'OBC',hi:'ओबीसी'},
  {id:'sc',i:'🧑‍🤝‍🧑',en:'SC',hi:'अनुसूचित जाति'},
  {id:'st',i:'🏕️',en:'ST',hi:'अनुसूचित जनजाति'}],
 income:[
  {id:'i1',i:'🪙',min:0,en:'Below ₹1 lakh',hi:'₹1 लाख से कम'},
  {id:'i2',i:'💰',min:1e5,en:'₹1 – 2.5 lakh',hi:'₹1 – 2.5 लाख'},
  {id:'i3',i:'💵',min:25e4,en:'₹2.5 – 5 lakh',hi:'₹2.5 – 5 लाख'},
  {id:'i4',i:'🏦',min:5e5,en:'Above ₹5 lakh',hi:'₹5 लाख से ज़्यादा'}],
 occupation:[
  {id:'farmer',i:'🌾',en:'Farmer',hi:'किसान'},
  {id:'laborer',i:'🧱',en:'Labourer',hi:'मज़दूर'},
  {id:'business',i:'🏪',en:'Small business',hi:'छोटा व्यापार'},
  {id:'student',i:'🎓',en:'Student',hi:'विद्यार्थी'},
  {id:'homemaker',i:'🏠',en:'Homemaker',hi:'गृहिणी'},
  {id:'other',i:'💼',en:'Other',hi:'अन्य'}],
 gender:[
  {id:'female',i:'👩',en:'Woman',hi:'महिला'},
  {id:'male',i:'👨',en:'Man',hi:'पुरुष'},
  {id:'other',i:'🧑',en:'Other',hi:'अन्य'}],
 state:[
  ['andhra','Andhra Pradesh','आंध्र प्रदेश'],['assam','Assam','असम'],['bihar','Bihar','बिहार'],
  ['chhattisgarh','Chhattisgarh','छत्तीसगढ़'],['delhi','Delhi','दिल्ली'],['gujarat','Gujarat','गुजरात'],
  ['haryana','Haryana','हरियाणा'],['jharkhand','Jharkhand','झारखंड'],['karnataka','Karnataka','कर्नाटक'],
  ['kerala','Kerala','केरल'],['mp','Madhya Pradesh','मध्य प्रदेश'],['maharashtra','Maharashtra','महाराष्ट्र'],
  ['odisha','Odisha','ओडिशा'],['punjab','Punjab','पंजाब'],['rajasthan','Rajasthan','राजस्थान'],
  ['tamilnadu','Tamil Nadu','तमिलनाडु'],['telangana','Telangana','तेलंगाना'],['up','Uttar Pradesh','उत्तर प्रदेश'],
  ['uttarakhand','Uttarakhand','उत्तराखंड'],['wb','West Bengal','पश्चिम बंगाल'],['other','Other','अन्य']
 ].map(([id,en,hi])=>({id,i:'📍',en,hi}))
};

// ---- Voice keywords (Hindi script + romanised + English) ----
const KW={
 occupation:{
  farmer:['kisan','किसान','farmer','kheti','खेती','krishi','कृषि'],
  laborer:['mazdoor','majdoor','मजदूर','मज़दूर','labour','labor','shramik','श्रमिक'],
  business:['vyapar','व्यापार','business','dukan','दुकान','vendor','thela','ठेला','udyam'],
  student:['student','छात्र','vidyarthi','विद्यार्थी','padhai','पढ़ाई','college','कॉलेज'],
  homemaker:['housewife','homemaker','grihini','गृहिणी','gharelu','घरेलू']},
 gender:{
  female:['mahila','महिला','aurat','औरत','female','woman','ladki','लड़की'],
  male:['purush','पुरुष','male ','aadmi','आदमी','ladka','लड़का',' man ']},
 category:{
  sc:[' sc ',' s c ','scheduled caste','अनुसूचित जाति','dalit','दलित'],
  st:[' st ',' s t ','tribal','janjati','जनजाति','आदिवासी','adivasi'],
  obc:['obc','ओबीसी','पिछड़ा','pichhda'],
  general:['general','सामान्य','jeneral']}
};

// ---- Documents ----
const DOCS={
 aadhaar:{en:'Aadhaar Card',hi:'आधार कार्ड'},
 land:{en:'Land Record (Khasra/Khatauni)',hi:'भूमि रिकॉर्ड (खसरा/खतौनी)'},
 income:{en:'Income Certificate',hi:'आय प्रमाण पत्र'},
 ration:{en:'Ration Card',hi:'राशन कार्ड'},
 bank:{en:'Bank Passbook',hi:'बैंक पासबुक'},
 caste:{en:'Caste Certificate',hi:'जाति प्रमाण पत्र'},
 pan:{en:'PAN Card',hi:'पैन कार्ड'},
 school:{en:'School/College Marksheet',hi:'स्कूल/कॉलेज की मार्कशीट'},
 photo:{en:'Passport Photo',hi:'पासपोर्ट फ़ोटो'},
 birth:{en:"Girl's Birth Certificate",hi:'बेटी का जन्म प्रमाण पत्र'},
 biz:{en:'Business Proof',hi:'व्यापार का प्रमाण'},
 mcp:{en:'Mother-Child Protection Card',hi:'मातृ-शिशु सुरक्षा कार्ड'}
};

// ---- 15 schemes. rule: empty/missing = any. Sample data; verify before real use. ----
const SCHEMES=[
 {id:'pmkisan',rule:{occupation:['farmer']},en:'PM-Kisan Samman Nidhi',hi:'पीएम-किसान सम्मान निधि',
  ben:{en:'₹6,000 per year in 3 instalments',hi:'₹6,000 प्रति वर्ष, 3 किस्तों में'},docs:['aadhaar','land','bank'],
  how:{en:'Register at pmkisan.gov.in or your CSC with Aadhaar, land record and bank passbook.',hi:'pmkisan.gov.in या अपने CSC पर आधार, भूमि रिकॉर्ड और बैंक पासबुक से पंजीकरण करें।'}},
 {id:'pmfby',rule:{occupation:['farmer']},en:'PM Fasal Bima Yojana',hi:'पीएम फसल बीमा योजना',
  ben:{en:'Crop insurance against drought, flood and pests at low premium',hi:'सूखा, बाढ़ और कीट से फसल बीमा, कम प्रीमियम पर'},docs:['aadhaar','land','bank'],
  how:{en:'Apply through your bank, CSC or pmfby.gov.in before the sowing deadline.',hi:'बुवाई की अंतिम तारीख से पहले बैंक, CSC या pmfby.gov.in पर आवेदन करें।'}},
 {id:'rythu',rule:{occupation:['farmer'],state:['telangana']},en:'Rythu Bharosa (Telangana)',hi:'रायतु भरोसा (तेलंगाना)',
  ben:{en:'Investment support per acre every season',hi:'हर सीज़न में प्रति एकड़ निवेश सहायता'},docs:['aadhaar','land','bank'],
  how:{en:'Contact your Mandal Agriculture Officer with land and bank details.',hi:'भूमि और बैंक विवरण के साथ अपने मंडल कृषि अधिकारी से मिलें।'}},
 {id:'pmjay',rule:{maxIncome:250000},en:'Ayushman Bharat PM-JAY',hi:'आयुष्मान भारत पीएम-जे ए वाई',
  ben:{en:'₹5 lakh health cover per family per year',hi:'प्रति परिवार प्रति वर्ष ₹5 लाख का स्वास्थ्य बीमा'},docs:['aadhaar','ration'],
  how:{en:'Check your name at mera.pmjay.gov.in, then get your card from an Ayushman Mitra at a hospital or CSC.',hi:'mera.pmjay.gov.in पर नाम देखें, फिर अस्पताल या CSC में आयुष्मान मित्र से कार्ड बनवाएं।'}},
 {id:'pmay',rule:{maxIncome:600000},en:'PM Awas Yojana',hi:'प्रधानमंत्री आवास योजना',
  ben:{en:'Up to ₹1.2 – 2.5 lakh help to build or buy a pucca house',hi:'पक्का घर बनाने या खरीदने के लिए ₹1.2 – 2.5 लाख तक की मदद'},docs:['aadhaar','income','bank','ration'],
  how:{en:'Apply through your Gram Panchayat, urban body or CSC.',hi:'अपनी ग्राम पंचायत, नगर निकाय या CSC के माध्यम से आवेदन करें।'}},
 {id:'ujjwala',rule:{gender:['female'],maxIncome:250000},en:'PM Ujjwala Yojana',hi:'पीएम उज्ज्वला योजना',
  ben:{en:'Free LPG gas connection for poor households',hi:'गरीब परिवारों को मुफ़्त एलपीजी गैस कनेक्शन'},docs:['aadhaar','ration','bank','photo'],
  how:{en:'Fill the KYC form at your nearest LPG distributor.',hi:'नज़दीकी गैस एजेंसी पर केवाईसी फ़ॉर्म भरें।'}},
 {id:'ssy',rule:{gender:['female']},en:'Sukanya Samriddhi Yojana',hi:'सुकन्या समृद्धि योजना',
  ben:{en:'High-interest, tax-free savings for your daughter under 10 years',hi:'10 साल से छोटी बेटी के लिए ऊंचे ब्याज वाली, कर-मुक्त बचत'},docs:['birth','aadhaar','photo'],
  how:{en:'Open an account at any post office or bank with just ₹250.',hi:'किसी भी डाकघर या बैंक में सिर्फ़ ₹250 से खाता खोलें।'}},
 {id:'mudra',rule:{occupation:['business']},en:'PM Mudra Yojana',hi:'पीएम मुद्रा योजना',
  ben:{en:'Loan up to ₹10 lakh without collateral',hi:'बिना गारंटी ₹10 लाख तक का ऋण'},docs:['aadhaar','pan','biz','bank'],
  how:{en:'Apply at any bank or at udyamimitra.in with a simple business plan.',hi:'किसी भी बैंक या udyamimitra.in पर सरल व्यापार योजना के साथ आवेदन करें।'}},
 {id:'standup',rule:{occupation:['business'],gender:['female']},en:'Stand-Up India',hi:'स्टैंड-अप इंडिया',
  ben:{en:'Bank loan of ₹10 lakh to ₹1 crore for a new business',hi:'नया व्यापार शुरू करने के लिए ₹10 लाख से ₹1 करोड़ तक का ऋण'},docs:['aadhaar','pan','biz','bank'],
  how:{en:'Apply at standupmitra.in or any bank branch.',hi:'standupmitra.in या किसी भी बैंक शाखा में आवेदन करें।'}},
 {id:'apy',rule:{occupation:['laborer','business','farmer']},en:'Atal Pension Yojana',hi:'अटल पेंशन योजना',
  ben:{en:'Monthly pension of ₹1,000 – 5,000 after age 60',hi:'60 साल के बाद ₹1,000 – 5,000 मासिक पेंशन'},docs:['aadhaar','bank'],
  how:{en:'Join at your bank branch or post office (age 18 – 40).',hi:'अपनी बैंक शाखा या डाकघर में जुड़ें (उम्र 18 – 40)।'}},
 {id:'shram',rule:{occupation:['laborer'],maxIncome:180000},en:'PM Shram Yogi Maan-dhan',hi:'पीएम श्रम योगी मान-धन',
  ben:{en:'₹3,000 monthly pension after age 60',hi:'60 साल के बाद ₹3,000 मासिक पेंशन'},docs:['aadhaar','bank'],
  how:{en:'Enrol at your nearest CSC with Aadhaar and bank account (age 18 – 40).',hi:'आधार और बैंक खाते के साथ नज़दीकी CSC पर नामांकन करें (उम्र 18 – 40)।'}},
 {id:'postmatric',rule:{occupation:['student'],category:['sc','st'],maxIncome:250000},en:'Post-Matric Scholarship (SC/ST)',hi:'पोस्ट-मैट्रिक छात्रवृत्ति (अनुसूचित जाति/जनजाति)',
  ben:{en:'Tuition fee and monthly allowance for college studies',hi:'कॉलेज पढ़ाई के लिए फ़ीस और मासिक भत्ता'},docs:['aadhaar','caste','income','school','bank'],
  how:{en:'Apply on scholarships.gov.in through your college.',hi:'अपने कॉलेज के माध्यम से scholarships.gov.in पर आवेदन करें।'}},
 {id:'matru',rule:{gender:['female']},en:'PM Matru Vandana Yojana',hi:'पीएम मातृ वंदना योजना',
  ben:{en:'₹5,000 for pregnant and nursing mothers (first child)',hi:'गर्भवती और स्तनपान कराने वाली माताओं को ₹5,000 (पहला बच्चा)'},docs:['aadhaar','bank','mcp'],
  how:{en:'Register at your Anganwadi centre or with your ASHA worker.',hi:'अपने आंगनवाड़ी केंद्र या आशा कार्यकर्ता के पास पंजीकरण करें।'}},
 {id:'ladli',rule:{gender:['female'],state:['mp'],maxIncome:250000},en:'Ladli Behna (Madhya Pradesh)',hi:'लाड़ली बहना (मध्य प्रदेश)',
  ben:{en:'Monthly money in your bank account',hi:'हर महीने सीधे बैंक खाते में राशि'},docs:['aadhaar','bank','ration'],
  how:{en:'Apply at your Gram Panchayat or ward office.',hi:'अपनी ग्राम पंचायत या वार्ड कार्यालय में आवेदन करें।'}},
 {id:'ladki',rule:{gender:['female'],state:['maharashtra'],maxIncome:250000},en:'Majhi Ladki Bahin (Maharashtra)',hi:'माझी लाडकी बहीण (महाराष्ट्र)',
  ben:{en:'Monthly money in your bank account',hi:'हर महीने सीधे बैंक खाते में राशि'},docs:['aadhaar','bank','ration','photo'],
  how:{en:'Apply through your Anganwadi, Gram Panchayat or the Nari Shakti Doot app.',hi:'आंगनवाड़ी, ग्राम पंचायत या नारी शक्ति दूत ऐप से आवेदन करें।'}}
];
